from ctypes.wintypes import tagSIZE
from unicodedata import name
from flask import Flask, jsonify, request, Response
from database.db import initialize_db
from database.models import Photo, Album
import json
from bson.objectid import ObjectId
import os
import urllib
import base64
import codecs

app = Flask(__name__)
'''
app.config['MONGODB_SETTINGS'] = {
    'host': 'mongodb://mongo:1048/flask-database'
    #'host': 'mongodb://localhost/flask-database'
}

'''
app.config['MONGODB_SETTINGS'] = {
    'db': 'flask-database',
    'host': 'mongo',
    'port': 27017
}

db = initialize_db(app)


def str_list_to_objectid(str_list):
    return list(
        map(
            lambda str_item: ObjectId(str_item),
            str_list
        )
    )


def object_list_as_id_list(obj_list):
    return list(
        map(
            lambda obj: str(obj.id),
            obj_list
        )
    )


'''
POST	/listAlbum	Album	{ message: ‘Album successfully created’, id: album_id }	201 - OK
'''


@app.route('/listAlbum', methods=['POST'])
def add_album():
    name = request.json['name']
    description = request.json['description']
    album = Album(name=name, description=description)
    album.save()
    output = {'message': 'Album successfully created', 'id': str(album.id)}
    return output, 201


'''
GET	/listAlbum/{album_id}	–	Single database object { id: album_id, name: name}	200
Update	PUT	/listAlbum/{album_id}	Album	{ message: ‘Album successfully updated’, id: album_id }	200
Delete	DELETE	/listAlbum/{album_id}	–	{ message: ‘Album successfully deleted’, id: album_id }	200
'''


@app.route('/listAlbum/<album_id>', methods=['GET', 'PUT', 'DELETE'])
def get_album_by_id(album_id):
    if request.method == "GET":
        album = Album.objects.get(id=album_id)
        output = {"id": str(album_id), "name": album.name}
        status_code = 200
        return output, status_code
    elif request.method == "PUT":
        album = Album.objects(id=album_id)
        body = request.get_json()
        album.name = body['name']
        album.description = request.json['description']
        keys = body.keys()
        Album.objects.get(id=album_id).update(**body)
        output = {'message': "Album successfully updated", 'id': str(album_id)}
        status_code = 200
        return output, status_code
    elif request.method == "DELETE":
        album = Album.objects.get_or_404(id=album_id)
        album.delete()
        output = {'message': "Album successfully deleted", 'id': str(album_id)}
        status_code = 200
        return output, status_code


'''
POST	/listPhoto	Photo (**)	{ message: ‘Photo successfully created’, id: photo_id }	201

'''


@app.route('/listPhoto', methods=['POST'])
def add_photo():
    posted_image = request.files['file']
    posted_data = request.form
    name = posted_data.get('name')
    tags = posted_data.get('tags')
    location = posted_data.get('location')
    albums = posted_data.get('albums')
    def_albums = Album.objects.get(name='Default')
    if def_albums is not None:
        photo = Photo(name=name, tags=tags, location=location,
                      albums=albums, image_file=posted_image)
        photo.save()
        output = {'message': "Photo successfully created", 'id': str(photo.id)}
        status_code = 201
        return output, status_code
    else:
        album = Album(name='Default')
        album.save()
        photo = Photo(name=name, tags=tags, location=location, albums=albums,
                      image_file=posted_image)
        photo.save()
        output = {'message': "Photo successfully created", 'id': str(photo.id)}
        status_code = 201
        return output, status_code


'''
GET	/listPhoto/{photo_id}	–Single database object { name: name, tags: [tags], location: location, albums: [albums], file: image_file }	200
DELETE	/listPhoto/{photo_id}	–	{ message: ‘Photo successfully deleted’, id: photo_id }	200
PUT	/listPhoto/{photo_id}	Photo (~)	{ message: ‘Photo successfully updated’, id: photo_id}	200
'''


@app.route('/listPhoto/<photo_id>', methods=['GET', 'DELETE', 'PUT'])
def get_photo_by_id(photo_id):
    if request.method == "GET":
        photo = Photo.objects.get(id=photo_id)
        base64_data = codecs.encode(photo.image_file.read(), 'base64')
        image = base64_data.decode('utf-8')
        output = {'name': photo.name, 'tags': photo.tags,
                  'location': photo.location, 'albums': photo.albums, 'file': image}
        return jsonify(output), 200
    elif request.method == "DELETE":
        photo = Photo.objects.get_or_404(id=photo_id)
        photo.delete()
        output = {'message': "Photo successfully deleted", 'id': str(photo_id)}
        status_code = 200
        return output, status_code
    elif request.method == "PUT":
        posted_data = request.json
        name = posted_data.get('name')
        tags = posted_data.get('tags')
        location = posted_data.get('location')
        albums = posted_data.get('albums')
        photo = Photo.objects.get(id=photo_id)
        if name is not None:
            photo.name = name
        if tags is not None:
            photo.tags = tags
        if location is not None:
            photo.location = location
        if albums is not None:
            albums = str_list_to_objectid(albums)
            photo.albums = albums
        photo.save()
        output = {'message': 'Photo successfully updated', 'id': photo_id}
        return jsonify(output), 200


'''
   GET	/listPhotos	tag (*)	Multiple database objects [{name: name, location: location, file: image_file}]	200
   GET	/listPhotos	albumName (*)	Multiple database objects [{name: name, location: location, file: image_file}]	200
'''


@app.route('/listPhotos', methods=['GET'])
def get_photos():
    tag = request.args.get('tag')
    albumName = request.args.get('albumName')
    photo_objects = None
    if tag is not None:
        photo_objects = Photo.objects(tags=tag)
        photos = []
        if photo_objects is not None:
            for photo in photo_objects:
                base64_data = codecs.encode(photo.image_file.read(), 'base64')
                image = base64_data.decode('utf-8')
                photos.append(
                    {'name': photo.name, 'location': photo.location, 'file': image})
        return jsonify(photos), 200
    if albumName is not None:
        album_photo_objects = []
        photo_objects = Photo.objects()
        for photo in photo_objects:
            for album in photo.albums:
                if album.name == albumName:
                    album_photo_objects.append(photo)
        photos = []
        for photo in album_photo_objects:
            base64_data = codecs.encode(photo.image_file.read(), 'base64')
            image = base64_data.decode('utf-8')
            photos.append(
                {'name': photo.name, 'location': photo.location, 'file': image})
        return jsonify(photos), 200


@ app.route('/')
def index():
    return '<h1>Photo Album App</h1>'
