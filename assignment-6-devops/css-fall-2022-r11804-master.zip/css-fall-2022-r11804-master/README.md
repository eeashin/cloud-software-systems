CI/CD build pipeline with GitLab
================================
This is your git repository for the assignment on creating a build pipeline with GitLab of the CS-E4190 course. See also the [assignment instructions on A+](https://plus.cs.aalto.fi/css/2021/devops/assignment-build-pipeline/#chapter-exercise-1) for additional information.

CI/CD pipeline
-----------------------
To view your DevOps pipeline you can do the following:

 * In the menu panel at the left side of your project click **CI/CD** > **Pipeline**
