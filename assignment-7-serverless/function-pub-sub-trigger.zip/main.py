import os
import json
import base64
from google.cloud import pubsub_v1
import functions_framework
# Add any imports that you may need, but make sure to update requirements.txt

PROJECT_ID = 'serverless-project-001'
publisher = pubsub_v1.PublisherClient()


@functions_framework.cloud_event
def restaurant_orders_pubsub(cloud_event):

    order_msg = base64.b64decode(cloud_event.data["message"]["data"]).decode()
    json_msg = json.loads(order_msg)
    order_type = json_msg['type']
    message = json.dumps(json_msg)
    encoded_message = message.encode('utf-8')

    if order_type == 'takeout':
        topic_path = publisher.topic_path(
            PROJECT_ID, 'restaurant_takeout_orders')
        publisher.publish(topic_path, data=encoded_message)
    elif order_type == 'eat-in':
        topic_path = publisher.topic_path(
            PROJECT_ID, 'restaurant_eat-in_orders')
        publisher.publish(topic_path, data=encoded_message)
    else:
        pass

    res = {"OK"}
    return res, 200
